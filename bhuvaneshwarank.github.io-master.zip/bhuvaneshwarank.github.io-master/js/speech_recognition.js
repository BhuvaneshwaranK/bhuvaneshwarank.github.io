var final_transcript = '';
var recognizing = false;
var recognition;



// reply processing
var two_line = /\n\n/g;
var one_line = /\n/g;
function linebreak(s) {
  return s.replace(two_line, '<p></p>').replace(one_line, '<br>');
}

var first_char = /\S/;
function capitalize(s) {
  return s.replace(first_char, function(m) { return m.toUpperCase(); });
}

function startConverting() {
  if (recognizing) {
    recognition.stop();
    return;
  }
  final_transcript = '';
  recognition.lang = 'en-US';
  recognition.start();
}

function show_result(){
     if(final_transcript.toLowerCase() == 'hello'){
                $('#hello_response').text("Hi! I'm Bhuvanesh")
                $('#hello_response').css('background-color', '#18bc9c');
            }
            else if(final_transcript.toLowerCase() == 'show me your picture'){
                $('#pic_response').append('<img class="img-fluid" src="img/profile3.jpg">');
            }
            else if(final_transcript.toLowerCase() == 'show expense report'){
                $('#report_response').animate({bottom: '-100px'});
            }
}

$(document).ready(function () {
     if('webkitSpeechRecognition' in window){
        // $("#emily-input-button").css("background-image", "url(../static/images/mic_new.gif)");
        // document.getElementById('emily-input-button').setAttribute("onclick","javascript:return startConverting();");
        recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.maxAlternatives = 5;

        recognition.onstart = function() {
            $('#mic').css('color', 'red');
            console.log("in onstart");
            recognizing = true;
        };
        recognition.onend = function() {
            $('#mic').css('color', 'black');
            console.log("in onend");
            recognizing = false;
            console.log("-------------",final_transcript);
            show_result();
            
        };
        recognition.onspeechstart = function() {    
            console.log("in onspeechstart");
            setTimeout(function(){
            	recognition.stop(); 
            }, 8000);
            
        };

        recognition.onresult = function(event) {
            console.log("in onresult");
            var interim_transcript = '';
            if (typeof(event.results) == 'undefined') {
            recognition.onend = null;
            recognition.stop();
            return;
            }
            for (var i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
                final_transcript += event.results[i][0].transcript;
            } else {
                interim_transcript += event.results[i][0].transcript;
            }
            }
            final_transcript = capitalize(final_transcript);
        };

    }
});



//  $("#mic1").click(function(){
//         if (recognizing) {
//             $('#mic1').css('color', 'black');
//             recognition.stop();
//             return;
//         }
//         $('#mic1').css('color', 'red');
//         startConverting();
// });
//   $("#mic2").click(function(){
//         if (recognizing) {
//             $('#mic2').css('color', 'black');
//             recognition.stop();
//             return;
//         }
//         $('#mic2').css('color', 'red');
//         startConverting();
// });
//   $("#mic3").click(function(){
//         if (recognizing) {
//             $('#mic3').css('color', 'black');
//             recognition.stop();
//             return;
//         }
//         $('#mic3').css('color', 'red');
//         startConverting();
// });


