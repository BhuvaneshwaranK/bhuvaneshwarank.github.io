import json
from watson_developer_cloud import ConversationV1
import nltk
#from nltk.corpus import stopwords
#from nltk.tokenize import word_tokenize
#stop_words = set(stopwords.words('english'))



def predict(query):
        try:
                # word_tokens = word_tokenize(query)
                # query = [w for w in word_tokens if not w in stop_words]
                # query = " ".join(query)
                conversation = ConversationV1(
                        username='84fb3853-9c55-4718-bee1-ec6457ddfe7a',
                        password='nwZOdNgBAZuZ',
                        version='2017-04-21')

                # replace with your own workspace_id
                workspace_id = 'a4b92721-2493-4dae-8f51-5ed36f501b23'

                response = conversation.message(workspace_id=workspace_id, message_input={'text': query})
                intent = response['intents'][0]['intent']
                confidence = response['intents'][0]['confidence']
                print("intent predicted",intent)
                print("confidence",confidence)
                if confidence >= 0.7:
                        return intent,intent
                elif confidence > 0.3 and confidence < 0.7:
                        return "confusion",intent
                else:
                        return "other","other"

        except:
                intent = "other"

        print("intentpredicted as-",intent)
        return intent,intent
        








