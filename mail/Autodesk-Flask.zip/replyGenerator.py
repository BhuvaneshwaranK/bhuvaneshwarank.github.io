import re
import json
import requests
from aimlHandler import aimlResponse
from model import predict
import traceback
import sqlite3 as db

def getReply(request):
    try:
        response = []
        slots=""
        query = request.form['query']
        dialog = request.form['dialog']
        intent = request.form['user_intent']
        data_dict = json.loads(request.form['data_dict'])
    except Exception as ex:
        print("In Reading request:", ex)
    
    if intent == "none":
        try:
            intent,dialog=predict(query)
            if intent!= "other" and intent!="confusion":
                qry = "select * from intent_response where intent like '{0}'".format(intent)
                with db.connect('./db/log.db', timeout=10) as conn:
                    data = conn.execute(qry).fetchall()
                initial_res = data[0][1]
                if "[link1]" in initial_res:
                    res = data[0][1]
                    links = data[0][2].split(",")
                    texts = data[0][3].split(",")
                    if len(links) == 2:
                        res = res.replace("[link1]","<a href='"+links[0]+"' target='_blank'>"+texts[0]+"</a>")
                        res = res.replace("[link2]","<a href='"+links[1]+"' target='_blank'>"+texts[1]+"</a>")
                    else:
                        res = res.replace("[link1]","<a href='"+links[0]+"' target='_blank'>"+texts[0]+"</a>")
                    response = [{"reply":res,"reply_type":"html","speech":res},
                    {"reply":"Is there anything else I can help you with?","reply_type":"simple","speech":"Is there anything else I can help you with?"}]
                    intent = "none"
                else:
                    response = [{"reply":initial_res,"reply_type":"html","speech":initial_res},
                    {"reply":"Is there anything else I can help you with?","reply_type":"simple","speech":"Is there anything else I can help you with?"}]
                    intent = "none"
            elif intent == "confusion":
                if dialog == "reset_password":
                    text = "So you are looking to reset your password, is that correct?. Please confirm."
                elif dialog == "change_password":
                    text = "So you are looking to change your password, is that correct?. Please confirm."
                elif dialog == "call_helpdesk":
                    text = "Looks like you are facing login issues, is that correct? Please confirm."
                elif dialog == "schedule_refresh":
                    text = "So you are looking for scheduling refresh for your machine, is that correct?. Please confirm."
                elif dialog == "hardware_options":
                    text = "So you are looking for harware options and configurations available in Autodesk, is that correct?. Please confirm."
                elif dialog == "exchange_hardware":
                    text = "So you are looking for your hardware exchange, is that correct?. Please confirm."
                elif dialog =="password_expire":
                    text = "So you are looking for password expiry related query, is that correct?. Please confirm."
                elif dialog =="juno_pulse":
                    text = "So you are looking for Junos Pulse and its VPN configurations, is that correct?. Please confirm."
                elif dialog == "configure_vpn":
                    text = "So you are looking for VPN configurations, is that correct?. Please confirm."
                elif dialog =="activate_duo":
                    text = "So you are looking to activate Duo app, is that correct?. Please confirm."
                response = [{"reply":text,"reply_type":"ask_yes_no","speech":text}]
                intent = "confusion_yes_or_no"
            else:
                if(query.lower() in yesWords):
                    intent = "none"
                    response = [{"reply":"Sure, Please tell me","reply_type":"simple","speech":"Sure, Please tell me"}]
                elif(query.lower() in noWords):
                    intent = "none"
                    response = [{"reply":"Thanks, Please buzz me again if you need any help.","reply_type":"simple","speech":"Thanks, Please buzz me again if you need any help."}]
                elif(re.search('[zrtypqsdfghjklmwxcvbnZRTYPQSDFGHJKLMWXCVBN]{5,}', query)):
                    intent = "none"
                    response = [{"reply":"I am not good in playing scribbling. Let me know if you are facing any issues related to Autodesk.:)","reply_type":"simple","speech":"I am not good in playing scribbling. Let me know if you are facing any issues related to Autodesk.:)"},
                    {"reply":"Is there anything else I can help you with?","reply_type":"simple","speech":"Is there anything else I can help you with?"}]
                else:
                    aimlResp = aimlResponse(query)
                    if(aimlResp):
                        intent = "none"
                        response = [{"reply":aimlResp,"reply_type":"simple","speech":aimlResp}]
                    else:
                        qry = "select * from intent_response where intent like '{0}'".format("call_helpdesk")
                        with db.connect('./db/log.db', timeout=10) as conn:
                            data = conn.execute(qry).fetchall()
                        initial_res = data[0][1]
                        if "[link1]" in initial_res:
                            res = data[0][1]
                            links = data[0][2].split(",")
                            texts = data[0][3].split(",")
                            if len(links) == 2:
                                res = res.replace("[link1]","<a href='"+links[0]+"' target='_blank'>"+texts[0]+"</a>")
                                res = res.replace("[link2]","<a href='"+links[1]+"' target='_blank'>"+texts[1]+"</a>")
                            else:
                                res = res.replace("[link1]","<a href='"+links[0]+"' target='_blank'>"+texts[0]+"</a>")
                            intent = "none"
                            response = [{"reply":res,"reply_type":"html","speech":res},
                            {"reply":"Is there anything else I can help you with?","reply_type":"simple","speech":"Is there anything else I can help you with?"}]
                        else:
                            intent = "none"
                            response = [{"reply":"Sorry, It's out of my scope. Please reach out to EIS helpdesk using +1-415-507-8888 or ext 78888 for better assistance.","reply_type":"html","speech":"Sorry, It's out of my scope. Please reach out to EIS helpdesk using +1-415-507-8888 or ext 78888 for better assistance."},
                            {"reply":"Is there anything else I can help you with?","reply_type":"simple","speech":"Is there anything else I can help you with?"}]

        except Exception as ex:
            print(traceback.print_exc())
            response = [{"reply":"Some Error occurred in Watson, Please try again later.","reply_type":"simple","speech":"Some Error occurred in Watson, Please try again later."}]
            return response,intent,dialog,slots,data_dict
    elif intent == "confusion_yes_or_no":
        if(query.lower() in yesWords):
            qry = "select * from intent_response where intent like '{0}'".format(dialog)
            with db.connect('./db/log.db', timeout=10) as conn:
                data = conn.execute(qry).fetchall()
            initial_res = data[0][1]
            if "[link1]" in initial_res:
                res = data[0][1]
                links = data[0][2].split(",")
                texts = data[0][3].split(",")
                if len(links) == 2:
                    res = res.replace("[link1]","<a href='"+links[0]+"' target='_blank'>"+texts[0]+"</a>")
                    res = res.replace("[link2]","<a href='"+links[1]+"' target='_blank'>"+texts[1]+"</a>")
                else:
                    res = res.replace("[link1]","<a href='"+links[0]+"' target='_blank'>"+texts[0]+"</a>")
                intent = "none"
                dialog = "initial"
                response = [{"reply":res,"reply_type":"html","speech":res},
                {"reply":"Is there anything else I can help you with?","reply_type":"simple","speech":"Is there anything else I can help you with?"}]
            else:
                intent = "none"
                dialog = "initial"
                response = [{"reply":initial_res,"reply_type":"html","speech":initial_res},
                {"reply":"Is there anything else I can help you with?","reply_type":"simple","speech":"Is there anything else I can help you with?"}]
            
        elif(query.lower() in noWords):
            intent = "none"
            dialog = "initial"
            response = [{"reply":"Please rephrase your question in a simple way, So I can assist you better.","reply_type":"simple","speech":"Please rephrase your question in a simple way, So I can assist you better."}]
        else:
            response = [{"reply":"Please confirm by saying yes or no.","reply_type":"simple","speech":"Please confirm by saying yes or no."}]            

    return response,intent,dialog,slots,data_dict

noWords = [ "no","absolutely not","apparently not","are not","by no means","certainly not","definitely not","hardly","heck no","hell no","i suppose not","negative", "never ", "nix  ","no no","no no no","no not at all", "no not really",  "no thank you","no thanks","no way","non","none","nope","not at all  ", "not by any means", "not completely","not especially","not particularly", "not really","not right now","not that i know of", "of course not","please no","nopeity-nope-nope","n-n-n-no","n-o","never","don't","dont","cancel it","never do it","dont go ahead","don't go ahead","you can't","nothing"] 
        
yesWords= ["ya","yo","yeah please","yes","yp","absolutely","absolutely correct", "absolutely yes", "affirmative", "affirmative yes","ah yes","apparently","apparently so","as far as i know", "aye", "by all means ","certainly","completely","constantly","correct","dam right","damn right","definite","definitely","especially","evidently","exactly","extremely","for sure","fully","generally","gladly  ","good enough","granted","heck yes","hell yes","i believe so","i decided yes","i think so","in this case","indeed","ja","most definitely","naturally","of course ","okie dokie","oui","please yes","positively","positively yes","precisely","right on","si","spot on","sure thing","surely","uh huh","uh-huh","undoubtedly","unquestionably","very well  ","why yes","willingly","without fail","word","yah","yeah","yep","yes please","yeah sure","yes really","yes right","yes sometimes","yes sure","yes yes","yes yes yes","yes you","you bet","you got it","yup","yyeah","yyep","yyes","yyyyyyyyyyyyyyyyesssssss","yuup","yuupp","yuur","yuuu","yuuup","yuuupppp","yus","yuperoo","yuperz","yupidydoda","yupiii","yupo","yupp","yuppers","yupperz","yuppie","yuppp","yuppper","yupppers","yupppp","yupppppp","yups","yupyup","yupz","yupzz","yesz","yesyes","yesyesyes","yesyesyesyes","yesyesyesyesyes","yesyesyesyesyesyes","yesyesyesyesyesyesyes","yez","yezz","yezzir","yha","yipyesg","yesh","yeshum","yeshums","yesi i","yesish","yesit it","yesly","yesm","yesn","yesq","yess","yesseess","yesshhh","yessiere","yessin","yessir","yessiree","yessireeee","yessm","yesss","yessss","yessum","yeper","yeperdoodles","yepers","yeples","yepo","yepp","yeppah","yepper","yeppers","yepperz","yeppie","yeppo","yeppp","yeppppppp","yepppppppppppppppppppppp","yeppurs","yeppy","yeppz","yeps","yepsiree","yepster","yepyep","yepyepyepyepyepyepy","yepz","yer","yeess","yeesss","yeessss","yeesssss","yehh","yehhh","yehhhh","yeh","yehhhhhhhhh","yerr","yerrr","yerrrr","yeea","yeeaaah","yeeaah","yeeaahh","yeeaahhh","yeeah","yeeargh","yeeeah","yeeeeaaaaaaah","yeeeeaaaaahhh","yeeeeaaah","yeeeeah","yeeeee","yeeeeeah","sure","okay","ok","k","go ahead","indeed","great","do it"]


