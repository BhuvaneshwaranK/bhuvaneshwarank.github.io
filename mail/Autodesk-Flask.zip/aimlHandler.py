import aiml,os


kernel = aiml.Kernel()
kernel.setBotPredicate("name","Emily")
kernel.setBotPredicate("age","23")
kernel.setBotPredicate("birthday","June 7, 1993")
kernel.setBotPredicate("boyfriend","I am single")
kernel.setBotPredicate("gender","Female")
kernel.setBotPredicate("master","Conversational AI Team")
kernel.setBotPredicate("wear","Pink Dress")
kernel.setBotPredicate("location","Bangalore")
kernel.setBotPredicate('User_name',"{{USERNAME}}")
if os.path.isfile("bot_brain.brn"):
	    kernel.bootstrap(brainFile = "bot_brain.brn")
else:
        kernel.bootstrap(learnFiles = os.path.abspath("aiml/Emily-startup.xml"), commands = "load aiml b")
        kernel.saveBrain("bot_brain.brn")

def aimlResponse(utterance):
    return kernel.respond(utterance)
