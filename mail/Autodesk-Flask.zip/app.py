from flask import Flask, make_response, render_template, request, jsonify
from flask_cors import CORS, cross_origin
import json,os,datetime,time
import replyGenerator
import traceback
import sqlite3 as db



app = Flask(__name__)
app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
app.config['Access-Control-Allow-Credentials'] = True

id = 1

@app.route('/_api/web/currentuser')
def current_user():
    """Placeholder for current user API to removed in production"""
    d = {"d":{"LoginName": "540583" , "Title":"James"}}
    return json.dumps(d)

@app.route("/")
def index():
     return make_response(render_template('index.html'),200)



@app.route('/getReply', methods=['POST'])
def getReply():
    """
    Bot's reply Module
    Input: UserQuery,Dialog,Conversation_id, userIntent
    Process : Lot of things to process, let's start with is user's intent different from dialog
    Output: reply [{reply,reply_type,sppech},{},etc],dialog ,id,needfeedback
    """ 
    response_text=""
    conversation_id = request.form['conversation_id']
    utterance = request.form['query']
    response,user_intent,dialog,slots,data_dict = replyGenerator.getReply(request)
    response_text = ' , '.join([item["reply"] for item in response])
    try:
        global id
        id = id+1
    except Exception as ex:
    	print(traceback.print_exc())
    return jsonify(
    dialog=dialog,
    reply=response,
    user_intent=user_intent,
    id=id,
    data_dict = data_dict
    )

@app.route('/conversationInitialize', methods=['POST'])
def conversationInitialize():
    """
    The starting Point of bot
    Input : ClientId (cts/540583) , ClientName (Bhuvaneshwaran,K)(not used now)
    Output: {ID:hash(max(id)+1), exists:true/false}
    """
    user_id = str(request.form['User_ID'])
    user_name = request.form['User_Name']
    conversation_hash = ""
    conversation_exists= "false"
    try:
        import uuid
        conversation_hash = str(uuid.uuid4())
        dialog = 'initial'
        reply = [{"reply":"{{GREETING}}, {{USERNAME}}","reply_type":"simple","speech":"{{GREETING}} {{USERNAME}}."},
        {"reply":"I am {{BOTNAME}}, your personal assistant. How can I help you?","reply_type":"simple","speech":"I am {{BOTNAME}}, your personal assistant. How can I help you?"}
        ]
    except Exception as ex:
        print(traceback.print_exc())
        conversation_id=""
        dialog='initial'
        exists=False,
        reply=[{"reply":"An eror occured",
                    "reply_type":"simple","speech":"An error occured"}]
        
    return jsonify( conversation_id=conversation_hash,
    dialog=dialog,
    exists=conversation_exists,
    reply=reply,
    id=0,
    needFeedBack = "false")


port = os.getenv('PORT', '5000')
if __name__ == "__main__":
	app.run(host='0.0.0.0', port=int(port))