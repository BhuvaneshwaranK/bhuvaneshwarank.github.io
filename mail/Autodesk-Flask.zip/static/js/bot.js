var $chatInput = $('#emily-input-field');
var dialog = "initial"; // initial-0 is for greeting 
var conversation_id, User_ID, User_Name, user_intent = "none";
var master_url = "https://autodesk-flask.mybluemix.net";
var data_dict = {};
var initialised = false;

$(document).ready(function () {
    createRing();
});

function getUserDetails() {
    initialised = true;
    var requestUri = master_url + "/_api/web/currentuser";
    var requestHeaders = { "accept": "application/json;odata=verbose" };
    $.ajax({
        url: requestUri,
        contentType: "application/json;odata=verbose",
        headers: requestHeaders,
        xhrFields: {
            withCredentials: true
        },
        success: function (data) { 
            data=(JSON.parse(data)); 
            var names = data.d.Title;
            User_Name = names;
            User_ID = data.d.LoginName;
            startConversation();
        },
        error: function (data) {
            console.log("Error getting user data");
        }
    });
}


function startConversation() {
    $.ajax({
        url: master_url + '/conversationInitialize',
        method: 'POST',
        xhrFields: {
            withCredentials: true
        },
        data: {
            User_ID: User_ID,
            timestamp: new Date(),
            User_Name: User_Name
        },
        success: function (data) {
            conversation_id = data.conversation_id;
            buildBot(data);

        },
        error: function (data) {
            console.log("Error stating the conversation");
        }
    });
}




// BOT BUILDING

function converse() {
    var query = ($chatInput.val());
if(query==""){
        return false;
    }
else{
    showUserQuery(query);
    scrollChatToBottom();
    $(".loader").css("display", "block");
    $.ajax({
        url:  master_url + "/getReply",
        method: 'POST',
        xhrFields: {
            withCredentials: true
        },
        data: { query: query, dialog: dialog, conversation_id: conversation_id, user_intent: user_intent,data_dict: JSON.stringify(data_dict)},
        success: function (data) {
            setUserIntent(data.user_intent);
            dialog = data.dialog;
            data_dict = data.data_dict;
            processBotReply(data);

        }
    });

    $chatInput.val("");
    return false;
}
}


function processBotReply(data) {
     var i =1;
    $.each(data.reply, function (index, item) {
        (function(i){  
           
            setTimeout(function(){
                if (item.reply_type == "simple") {                
                    showSimpleBotReply(synthesizeReply(item.reply), data.id);            
                } else if (item.reply_type == "html") {
                    showhtml(synthesizeReply(item.reply), data.id);
                }
                else if (item.reply_type == "ask_yes_no") {
                    showyesno(synthesizeReply(item.reply), data.id);
                }
                scrollChatToBottom();                
            }, i*1000 );
           
        })(i);
        i++;
    });
}

function synthesizeReply(reply) {
    var reply = reply.replace("{{BOTNAME}}", "Emily");
    reply = reply.replace("{{USERNAME}}", User_Name);
    var greeting = (new Date().getHours() > 11) ? ((new Date().getHours() >= 16) ? "Good Evening" : "Good Afternoon") : "Good Morning";
    reply = reply.replace("{{GREETING}}", greeting);
    return reply;
}

function showhtml(reply, id) {
    $(".loader").css("display", "none");
    var $chatBox = $('#botReplyDiv').clone().prop('id', "botdiv" + id);;
    var $loading = $('.loader');
    $chatBox.css("display", "block");
    $chatBox.find('p').html($('<p/>').html(reply));

    $('#emily-chat-history').append($chatBox);
    $chatBox.insertBefore($loading);

}

function showyesno(reply, id) {
    var design = '<p>'+reply+'</p><break><div style="text-align: center;"><button style="margin-right: 10px;" type="button" class="btn btn-success" id="yes_btn" onclick="showresponse(\'Yes\');">Yes</button><button type="button" class="btn btn-danger" id="no_btn" onclick="showresponse(\'No\');">No</button></div>'
    $(".loader").css("display", "none");
    var $chatBox = $('#botReplyDiv').clone().prop('id', "botdiv" + id);
    var $loading = $('.loader');
    $chatBox.css("display", "block");
    $chatBox.find('p').html($('<p/>').html(design));
    $('#emily-chat-history').append($chatBox);
    $chatBox.insertBefore($loading);

}

function showresponse(query){
    showUserQuery(query);
    scrollChatToBottom();
    $(".loader").css("display", "block");
    $.ajax({
        url:  master_url + "/getReply",
        method: 'POST',
        xhrFields: {
            withCredentials: true
        },
        data: { query: query, dialog: dialog, conversation_id: conversation_id, user_intent: user_intent,data_dict: JSON.stringify(data_dict)},
        success: function (data) {
            setUserIntent(data.user_intent);
            dialog = data.dialog;
            data_dict = data.data_dict;
            processBotReply(data);

        }
    });

    $chatInput.val("");
    return false;
}



function showSimpleBotReply(reply, id) {
    $(".loader").css("display", "none");
    var $chatBox = $('#botReplyDiv').clone().prop('id', "botdiv" + id);;
    var $loading = $('.loader');
    $chatBox.css("display", "block");
    $chatBox.find('p').html($('<p/>').text(reply));

    $('#emily-chat-history').append($chatBox);
    $chatBox.insertBefore($loading);

}

function showUserQuery(query) {
    var $chatBox = $('#userInputDiv').clone();
    var $loading = $('.loader');
    $chatBox.css("display", "block");
    $chatBox.find('p').html($('<p/>').text(query));
    $('#emily-chat-history').append($chatBox);
    $chatBox.insertBefore($loading);

}
function setUserIntent(intent) {
    user_intent = intent;
}
function setQuery(query) {
    $chatInput.val(query);
    converse();
}
